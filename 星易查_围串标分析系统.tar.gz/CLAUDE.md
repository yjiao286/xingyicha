# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## 项目概述

围串标风险识别分析系统（"星易查"）— 基于 Flask 的 Web 应用，通过多维度分析投标文件来检测围标串标行为。依据《中华人民共和国招标投标法实施条例》第四十条。

## 开发命令

```bash
# 激活虚拟环境并运行
./venv/bin/python3 app.py 5001          # 开发模式 (debug=DEBUG env, default False)

# Docker 部署（生产模式：gunicorn）
docker compose up -d                    # 构建并启动，绑定 5001 端口

# 语法检查
./venv/bin/python3 -c "import py_compile; py_compile.compile('app.py', doraise=True)"

# 依赖自检（便携包目标机校验）
./venv/bin/python3 app.py --check

# 健康检查
curl -s -o /dev/null -w "%{http_code}" http://localhost:5001/

# 停止开发服务器
lsof -ti:5001 | xargs kill -9
```

环境变量：`DEBUG=1`（开启 Flask debug）、`SECRET_KEY`（随机生成）、`MAX_CONTENT_LENGTH_MB=200`、`LOG_LEVEL=INFO`。

## 架构

### 单体应用 (`app.py`，~4100 行)

所有后端逻辑集中于 `app.py`，无 Blueprint 或模块拆分。代码按功能区段组织，用 `# ── Section ──` 注释分隔：

| 区段 | 功能 |
|------|------|
| Helpers | `sanitize_text`、`_find_tool`、`_safe_save`、`_is_within_upload_folder` |
| Config | `CONFIG` 字典集中管理所有分析阈值 |
| .doc Conversion | LibreOffice 转换（缓存避免重复启动）；antiword/catdoc 回退 |
| Metadata Extraction | .docx（XML）、.pdf（PDF info）、.doc（OLE2 + KSO，含值格式验证） |
| Text Extraction | 纯文本 + 表格；PDF 进度回调 + 早停（连续空页）；.txt 编码自动识别（UTF-8/GB18030） |
| Personnel Extraction | 中文姓名（2-4字）+ 英文姓名（字母/连字符/空格，2-40字） |
| Price Extraction | 含全中文大写数字解析（`_cn_to_number`）；6 通道提取 + 后校验 |
| Text Similarity | k-gram 哈希索引 + 双向最大延伸（O(n+m)，替代全文 SequenceMatcher）+ 空白归一化；三层过滤（参照/规则/全局共现）+ 实质性评分；近似段落检测（difflib 段落对，捕获轻度编辑串标） |
| Document Structure | 扩展标题正则（中文数字/章节/Section/附录/字母编号） |
| Comprehensive Analysis | `run_full_analysis()` + 加权评分 + 协同加分 + 三档结论 |
| Report Generation | `generate_report_docx()`（含分项报价比对 + 评分规则） |
| Routes | Flask API 端点（流式 NDJSON 进度 + uuid 前缀文件名 + body 限制 + 路径校验） |

### 分析维度（5 个维度）

1. **元数据比对** — 交叉比对创建者/修改者/应用/模板/WPS 硬件ID/ICV；多卷文件聚合全部卷的元数据
2. **文本相似度** — `find_common_segments()`（k-gram 索引 + 双向最大延伸，空白归一化，支持中英混排）；三层过滤 + 四维实质性评分；`_find_near_duplicate_paragraphs()` 检测轻度编辑的近似段落
3. **人员比对** — 中文 + 英文姓名提取；6 层交叉匹配（同名/同手机/同身份证/授权交叉/修改人/重叠率）
4. **报价分析** — 总价/分项/成本明细；中文大写金额解析；分项模糊聚类（LCS + Jaccard 2-gram）+ 等差数列检测
5. **文档结构** — 扩展标题格式（第X章/Section X/附录X/字母编号）

### 前端

- `templates/index.html` — 单页面应用（拖拽上传、结果展示标签页）
- `static/css/style.css` — 所有样式
- `static/js/main.js` — 所有前端逻辑（文件上传、流式 NDJSON 进度、结果渲染、报告下载）

### 文件格式支持

- `.docx` — 原生支持（python-docx）
- `.pdf` — 原生支持（pypdf）
- `.doc` — 文本需安装 LibreOffice（优先项）或 antiword（通过 `extract_doc_text_raw()`）；元数据通过 `olefile`（Python 依赖）读 OLE2 属性流（同 .docx 维度）
- `.txt` - 纯文本支持（OCR 标书输出）；`_read_text_file()` 自动识别 UTF-8(含BOM)/GB18030 编码；无文档元数据，元数据维度按"无法判断"处理

### API 端点

| 路由 | 方法 | 说明 |
|------|------|------|
| `/` | GET | 渲染主页面 |
| `/api/upload` | POST | 上传多份标书文件（uuid 前缀防覆盖），返回文件名列表 |
| `/api/analyze` | POST | 接收 `{files: [filename, ...]}`，返回完整分析结果（JSON）。路径穿越保护：仅接受纯文件名 |
| `/api/analyze_stream` | POST | 上传+分析，返回 NDJSON 流式进度事件（最终 `type: result`），**前端首选** |
| `/api/single_upload_and_analyze` | POST | 合并上传+分析（JSON 响应） |
| `/api/report` | POST | 接收 `{analysis: {...}}`，校验结构完整性，返回 .docx 报告 |
| `/api/history` | GET | 列出所有历史分析记录 |
| `/api/history/<id>` | GET | 加载指定历史记录（ID 格式白名单校验） |
| `/api/history/<id>` | DELETE | 删除指定历史记录（格式校验） |

### 关键配置

- 端口：`5001`
- 上传目录：环境变量 `UPLOAD_FOLDER` 或临时目录；文件名 uuid 前缀防并发覆盖
- `MAX_CONTENT_LENGTH`：200MB（环境变量 `MAX_CONTENT_LENGTH_MB` 覆盖）
- `ANALYSIS_TIMEOUT`：270 秒（< gunicorn timeout 300）
- `requirements.txt`：flask, python-docx, pypdf, gunicorn, olefile
- Docker 镜像基于 `python:3.11-slim`，另安装 `antiword`

### 参照文件功能

当用户上传招标文件/技术要求作为"参照文件"时，`text_similarity_analysis()` 会先索引参照文件中的文本段落。标书之间发现的相似段落中，在参照文件中出现过的部分会被标记为 `.is_reference_from_template = True`，从而降低其风险权重。这一过滤逻辑在 `classify_abnormal_reason()` 中生效：被过滤的匹配项会被排除或降级。
