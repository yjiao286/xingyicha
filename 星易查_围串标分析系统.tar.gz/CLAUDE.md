# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## 项目概述

围串标风险识别分析系统（"星易查"）— 基于 Flask 的 Web 应用，通过多维度分析投标文件来检测围标串标行为。依据《中华人民共和国招标投标法实施条例》第四十条。

## 开发命令

```bash
# 激活虚拟环境并运行
./venv/bin/python3 app.py 5001          # 开发模式 (debug=True)
./venv/bin/python3 app.py 5001 prod     # 生产模式 (gunicorn, debug=False)

# Docker 部署
docker compose up -d                    # 构建并启动，绑定 5001 端口

# 语法检查
./venv/bin/python3 -c "import py_compile; py_compile.compile('app.py', doraise=True)"

# 健康检查
curl -s -o /dev/null -w "%{http_code}" http://localhost:5001/

# 停止开发服务器
lsof -ti:5001 | xargs kill -9
```

## 架构

### 单体应用 (`app.py`，~1442 行)

所有后端逻辑集中于 `app.py`，无 Blueprint 或模块拆分。代码按功能区段组织，用 `# ── Section ──` 注释分隔：

| 区段 | 功能 |
|------|------|
| Helpers | `sanitize_text`、`_find_tool` |
| .doc Conversion | 通过 LibreOffice/antiword/catdoc 将 .doc 转为可读文本 |
| Metadata Extraction | 从 .docx（XML 属性 + KSO 自定义属性）和 .pdf 提取元数据 |
| Text Extraction | 纯文本提取，含表格文本 |
| Personnel Extraction | 从文本中提取人员姓名（中文姓名正则） |
| Price Extraction | 解析投标报价，提取总价、分项价格、成本明细 |
| Text Similarity | 多文档间查找公共文本段落，支持参照文件过滤 |
| Document Structure | 提取文档目录/标题结构 |
| Comprehensive Analysis | `run_full_analysis()` 编排所有分析模块并生成交叉比对结果 |
| Report Generation | `generate_report_docx()` 生成 .docx 格式分析报告 |
| Routes | Flask API 端点 |

### 分析维度（5 个维度）

1. **元数据比对** — 交叉比对所有文档对的创建者、修改者、编辑时长、模板、公司名、应用程序名称/版本、页数/字数
2. **文本相似度** — 使用 `find_common_segments()`（滑动窗口 + 哈希匹配）检测文档间的共享段落；通过 `.is_reference_from_template` 字段区分来自招标文件的模板内容
3. **人员比对** — 提取中国姓名，计算所有文档对之间的交集
4. **报价分析** — 提取总价、分项单价和成本明细；通过 `_build_sub_item_comparison()` 比较文档间的差异
5. **文档结构** — 提取标题/目录结构

### 前端

- `templates/index.html` — 单页面应用（拖拽上传、结果展示标签页）
- `static/css/style.css` — 所有样式
- `static/js/main.js` — 所有前端逻辑（文件上传、API 调用、结果渲染、报告下载）

### 文件格式支持

- `.docx` — 原生支持（python-docx）
- `.pdf` — 原生支持（pypdf）
- `.doc` — 需安装 LibreOffice（优先项）或 antiword；通过 `extract_doc_text_raw()` 处理

### API 端点

| 路由 | 方法 | 说明 |
|------|------|------|
| `/` | GET | 渲染主页面 |
| `/api/upload` | POST | 上传多个标书文件，返回已保存的文件名列表 |
| `/api/analyze` | POST | 接收 `{files: [filename, ...]}`，返回完整分析结果（JSON） |
| `/api/report` | POST | 接收 `{analysis: {...}}`，返回 .docx 报告文件（下载） |
| `/api/single_upload_and_analyze` | POST | 合并上传+分析，支持 `files`（标书）和可选 `ref_files`（招标文件/技术要求） |

### 关键配置

- 端口：`5001`
- 上传目录：环境变量 `UPLOAD_FOLDER` 或临时目录
- `requirements.txt`：flask, python-docx, pypdf, gunicorn
- Docker 镜像基于 `python:3.11-slim`，另安装 `antiword`

### 参照文件功能

当用户上传招标文件/技术要求作为"参照文件"时，`text_similarity_analysis()` 会先索引参照文件中的文本段落。标书之间发现的相似段落中，在参照文件中出现过的部分会被标记为 `.is_reference_from_template = True`，从而降低其风险权重。这一过滤逻辑在 `classify_abnormal_reason()` 中生效：被过滤的匹配项会被排除或降级。
